Imports System

Public Module MyProgram
    Sub Main
        Console.WriteLine("Hitung BMR")
        Dim nama As String, jenisKelamin As String
        Dim usia As Integer
        Dim berat As Double, tinggi As Double, bMRPria As Double, bMRWanita As Double, tDEE As Double, faktorAktivitas As Double

        Console.WriteLine("MASUKAN NAMA ANDA")
        nama = Console.ReadLine()
        Console.WriteLine("APA JENIS KELAMIN ANDA(laki-laki/perempuan)")
        jenisKelamin = Console.ReadLine()
        faktorAktivitas = 1.375
        If jenisKelamin = "laki laki" Then
            Console.WriteLine("BERAPA BERAT BADAN ANDA")
            berat = inputValue()
            Console.WriteLine("BERAPA TINGGI BADAN ANDA")
            tinggi = inputValue()
            Console.WriteLine("BERAPA USIA ANDA")
            usia = inputValue()
            bMRPria = 10 * berat + 6.25 * tinggi - 5 * usia + 5
            tDEE = bMRPria * faktorAktivitas
            Console.WriteLine("atas nama:" & nama)
            Console.WriteLine("jenis kelamin:" & jenisKelamin)
            Console.WriteLine("BMR:" & bMRPria)
            Console.WriteLine("TDEE:" & tDEE)
        Else
            If jenisKelamin = "perempuan" Then
                Console.WriteLine("BERAPA BERAT BADAN ANDA")
                berat = inputValue()
                Console.WriteLine("BERAPA TINGGI BADAN ANDA")
                tinggi = inputValue()
                Console.WriteLine("BERAPA USIA ANDA")
                usia = inputValue()
                bMRWanita = 10 * berat + 6.25 * tinggi - 5 * usia - 161
                tDEE = bMRWanita * faktorAktivitas
                Console.WriteLine("atas nama:" & nama)
                Console.WriteLine("jenis kelamin:" & jenisKelamin)
                Console.WriteLine("BMR:" & bMRWanita)
                Console.WriteLine("TDEE:" & tDEE)
            Else
                Console.WriteLine("tolong jenis kelamin yang dimasukan antara perempuan atau laki laki")
            End If
        End If
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
