Imports System

Public Module MyProgram
    Sub Main
        Dim sisa As Integer, p100 As Integer, p50 As Integer, p20 As Integer, p10 As Integer, p5 As Integer, p2 As Integer, p1 As Integer, koin As Integer

        Console.WriteLine("MASUKKAN UANG KEMBALIAN")
        sisa = inputValue()
        p100 = sisa / 100000
        sisa = sisa Mod 100000
        p50 = sisa / 50000
        sisa = sisa Mod 50000
        p20 = sisa / 20000
        sisa = sisa Mod 20000
        p10 = sisa / 10000
        sisa = sisa Mod 10000
        p5 = sisa / 5000
        sisa = sisa Mod 5000
        p2 = sisa / 2000
        sisa = sisa Mod 2000
        p1 = sisa / 1000
        sisa = sisa Mod 1000
        koin = sisa
        Console.WriteLine("Rp.100000:" & p100)
        Console.WriteLine("Rp.50000:" & p50)
        Console.WriteLine("Rp.20000:" & p20)
        Console.WriteLine("Rp.10000:" & p10)
        Console.WriteLine("Rp.5000:" & p5)
        Console.WriteLine("Rp.2000:" & p2)
        Console.WriteLine("Rp.1000:" & p1)
        Console.WriteLine("sisa koin:Rp." & koin)
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
