Imports System

Public Module MyProgram
    Sub Main
        Console.WriteLine("PENGHITUNGAN BMI")
        Dim berat As Double, tinggi As Double, bMI As Double, usia As Double
        Dim isideal As Boolean

        Console.WriteLine("masukan berat badan anda")
        berat = inputValue()
        Console.WriteLine("masukan tinggi badan anda")
        tinggi = inputValue()
        bMI = berat / tinggi * tinggi
        Console.WriteLine("masukan usia anda")
        usia = inputValue()
        If bMI < 18.5 Then
            Console.WriteLine("underweight")
        Else
            If 18.5 <= bMI And bMI < 25.0 Then
                Console.WriteLine("ideal/normal")
                If usia >= 18 And usia <= 60 Then
                    isideal = True
                Else
                    isideal = False
                End If
                Console.WriteLine("isideal:" & isideal)
            Else
                If 25.0 <= bMI And bMI < 30.0 Then
                    Console.WriteLine("overweight")
                Else
                    If bMI >= 30.0 Then
                        Console.WriteLine("obesitas")
                    End If
                End If
            End If
        End If
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
