Imports System

Public Module MyProgram
    Sub Main
        Dim penghasilan As Double, agunan As Double, totalPinjaman As Double, pinjaman As Double
        Dim skorKredit As Integer, lamaUsaha As Integer
        Dim b As String
        Dim syaratFinansial As Boolean, syaratRekamJejak As Boolean, statusKelayakan As Boolean, tidakTerdaftarBlacklist As Boolean

        Console.WriteLine("BERAPA JUMLAH YANG INGIN ANDA PINJAM")
        pinjaman = inputValue()
        Console.WriteLine("MASUKAN JUMLAH PENGHASILAN ANDA")
        penghasilan = inputValue()
        Console.WriteLine("MASUKAN NILAI AGUNAN ANDA")
        agunan = inputValue()
        Console.WriteLine("MASUKAN SKOR KREDIT ANDA")
        skorKredit = inputValue()
        Console.WriteLine("BERAPA LAMA USAHA ANDA")
        lamaUsaha = inputValue()
        Console.WriteLine("APAKAH ANDA TERDAFTAR BLACKLIST(ya/tidak)")
        b = Console.ReadLine()
        If penghasilan >= 5000000 Or agunan >= 1.5 * pinjaman Then
            syaratFinansial = True
            Console.WriteLine("syaratFinansial:" & syaratFinansial)
            If skorKredit >= 70 And lamaUsaha >= 2 Then
                syaratRekamJejak = True
                Console.WriteLine("syaratRekamJejak:" & syaratRekamJejak)
                If b = "tidak" Then
                    tidakTerdaftarBlacklist = True
                    Dim biayaAdministrasi As Double, angsuran As Double

                    Console.WriteLine("BIAYA ADMINISTRASI DIKENAKAN 2,5%")
                    biayaAdministrasi = pinjaman * 0.025
                    totalPinjaman = pinjaman + biayaAdministrasi
                    angsuran = totalPinjaman / 12
                    Console.WriteLine("BIAYA ADMINISTRASI SEBESAR:" & biayaAdministrasi)
                    Console.WriteLine("TOTAL PINJAMAN ANDA SEBESAR:" & totalPinjaman)
                    Console.WriteLine("DENGAN ANGSURAN:" & angsuran)
                Else
                    tidakTerdaftarBlacklist = False
                    Console.WriteLine("tidakTerdaftarBlacklist" & tidakTerdaftarBlacklist)
                    Console.WriteLine("ANDA TIDAK LAYAK DIBERIKAN PINJAMAN")
                End If
            Else
                syaratRekamJejak = False
                Console.WriteLine("syaratRekamJejak:" & syaratRekamJejak)
                Console.WriteLine("ANDA TIDAK LAYAK DIBERIKAN PINJAMAN")
            End If
        Else
            syaratFinansial = False
            Console.WriteLine("syaratFinansial:" & syaratFinansial)
            Console.WriteLine("ANDA TIDAK LAYAK DIBERIKAN PINJAMAN")
        End If
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
